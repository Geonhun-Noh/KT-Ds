
public class Americano {
	public int orderCount;

	public void Americano(int orderCount) {
		this.orderCount = orderCount;
}

	public int charge() {
		int total=4000 * this.orderCount;
		return total;
	}
	

}
