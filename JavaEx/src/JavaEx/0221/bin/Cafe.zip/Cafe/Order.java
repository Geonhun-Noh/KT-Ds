
public class Order{
	public static void main(String[] args) {
		Customer cst1 = new Customer("Frank",1,5,50000);
		Customer cst2 = new Customer("Gerrard",2,3,45000);
		Customer cst3 = new Customer("Scholes",3,2,46000);
		
		Americano ame = new Americano();
		Latte lat = new Latte();
		
		cst1.takeAme(ame);
		cst1.takeLat(lat);
		cst1.showInfo();
		
		
		cst2.takeAme(ame);
		cst2.takeLat(lat);
		cst2.showInfo();
		
		cst3.takeAme(ame);
		cst3.takeLat(lat);
		cst3.showInfo();
	}
	
	


}
