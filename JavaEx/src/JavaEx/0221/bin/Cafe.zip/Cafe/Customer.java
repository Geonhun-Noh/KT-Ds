
public class Customer {
	public String customerName;
	public int ameOrder;
	public int latOrder;
	public int charge;
	public int money;
	
	public Customer(String customerName, int ameOrder, int latOrder,int money) {
		this.customerName=customerName;
		this.ameOrder=ameOrder;
		this.latOrder=latOrder;
		this.money=money;
	}
	
	public void takeAme(Americano ame) {
		ame.orderCount=this.ameOrder;
		this.charge += ame.charge();
		this.money = this.money - ame.charge();
	}
	
	public void takeLat(Latte lat) {
		lat.orderCount=this.latOrder;
		this.charge += lat.charge();
		this.money=this.money-lat.charge();
	}
	public int totalCount() {
		int total = ameOrder + latOrder;
		return total;
	}
	
	
	public void showInfo() {
		System.out.println("�ֹ��Ͻ� ����� �� "+ totalCount() + "���̸� "+ charge + "�� �����ϸ� �ܾ��� "+money+"�Դϴ�.");
	}

}
