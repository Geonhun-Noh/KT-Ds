
public class Latte {
	public int orderCount;

	public void Latte(int orderCount) {
		this.orderCount = orderCount;
}

	public int charge() {
		int total=4500 * this.orderCount;
		return total;
	}
}



